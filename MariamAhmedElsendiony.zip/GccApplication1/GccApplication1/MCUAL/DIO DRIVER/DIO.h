/*
 * DIO.h
 *
 * Created: 9/28/2022 1:53:23 PM
 *  Author: Vivi
 */ 
#ifndef DIO_H_
#define DIO_H_
#include "../../HARDWARE/Registers.h"

//all driver typedefs 
//all macros
//port number
#define PORT_A 'A'
#define PORT_B 'B'
#define PORT_C 'C'
#define PORT_D 'D'
//direction
#define IN 0
#define OUT 1
//value
#define HIGH 1
#define LOW 0
typedef enum EN_dioError_t
{
	 wrongport,wrongPin,OK_DIO,errordirection,errorvalue
}EN_dioError_t;

//function declarations
EN_dioError_t DIO_init(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t INOUT ); //initialize
EN_dioError_t DIO_write(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t HIGHLOW); //write data to DIO
EN_dioError_t DIO_toggle(uint8_t PORTNUMBER,uint8_t PINNUMBER); //Toggle DIO previous state
EN_dioError_t DIO_read(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t * value); //read DIO

#endif
