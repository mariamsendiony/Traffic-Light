/*
 * DIO.c
 *
 * Created: 9/28/2022 1:52:42 PM
 *  Author: Vivi
 */ 
#include "DIO.h"
EN_dioError_t  DIO_init(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t INOUT )
{//check the port number and configure the sent pin number with the sent direction
	if(PINNUMBER>7 || PINNUMBER<0 )
	{
		return wrongPin;
	}
	switch(PORTNUMBER)
	{
		case PORT_A:
		if(INOUT ==IN)
		{
			DDRA&=~(1<<PINNUMBER);
			return OK_DIO;
		}
		else if (INOUT ==OUT)
		{
			DDRA|=(1<<PINNUMBER);
			return OK_DIO;
		}
		else
		{
			//error handling
			return errordirection;
		}
		
		case PORT_B:
		if(INOUT ==IN)
		{
			DDRB&=~(1<<PINNUMBER);
			return OK_DIO;
		}
		else if (INOUT ==OUT)
		{
			DDRB|=(1<<PINNUMBER);
			return OK_DIO;
		}
		else
		{
			return errordirection;
		}
		
		case PORT_C:
		if(INOUT ==IN)
		{
			DDRC&=~(1<<PINNUMBER);
			return OK_DIO;
		}
		else if(INOUT ==OUT)
		{
			DDRC|=(1<<PINNUMBER);
			return OK_DIO;
		}
		else
		{
			return errordirection;
		}
		
		case PORT_D:
		if(INOUT ==IN)
		{
			DDRD&=~(1<<PINNUMBER);
			return OK_DIO;
		}
		else if (INOUT==OUT)
		{
			DDRD|=(1<<PINNUMBER);
			return OK_DIO;
		}
		else
		{
			return errordirection;
		}
		
		default:
		{
			return wrongport;
		}
		
		
		
	}
	
}


EN_dioError_t  DIO_write(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t HIGHLOW)
{//check the port number and the sent value high or low and configure the sent pin number accordingly
	if(PINNUMBER>7 || PINNUMBER<0 )
	{
		return wrongPin;
	}
	switch(PORTNUMBER)
	{
		case(PORT_A):
		
			if(HIGHLOW==LOW)
			{
				PORTA &=~(1<<PINNUMBER);
				return OK_DIO;
			}
			else if(HIGHLOW==HIGH)
			{
				PORTA|=(1<<PINNUMBER);
				return OK_DIO;
			}
			else
			{
				//ERROR HANDLING
				return errorvalue;
			}
			
		case(PORT_B):
			
			if(HIGHLOW==LOW)
			{
				PORTB &=~(1<<PINNUMBER);
				return OK_DIO;
			}
			else if(HIGHLOW==HIGH)
			{
				PORTB|=(1<<PINNUMBER);
				return OK_DIO;
			}
			else
			{
				//ERROR HANDLING
				return errorvalue;
			}
			
		case(PORT_C):
			
			if(HIGHLOW==LOW)
			{
				PORTC &=~(1<<PINNUMBER);
				return OK_DIO;
			}
			else if(HIGHLOW==HIGH)
			{
				PORTC|=(1<<PINNUMBER);
				return OK_DIO;
			}
			else
			{
				//ERROR HANDLING
				return errorvalue;
			}
		
		case(PORT_D):
			
			if(HIGHLOW==LOW)
			{
				PORTD &=~(1<<PINNUMBER);
				return OK_DIO;
			}
			else if(HIGHLOW==HIGH)
			{
				PORTD|=(1<<PINNUMBER);
				return OK_DIO;
			}
			else
			{
				//ERROR HANDLING
				return errorvalue;
			}
		
		  default:
		  {
			  return wrongport;
		  }
	}
}
EN_dioError_t  DIO_toggle(uint8_t PORTNUMBER,uint8_t PINNUMBER)
{
	if(PINNUMBER>7 || PINNUMBER<0 )
	{
		return wrongPin;
	}
	switch(PORTNUMBER)
	{
		case(PORT_A):
		PORTA^=(1<<PINNUMBER);
		return OK_DIO;
		case(PORT_B):
		PORTB^=(1<<PINNUMBER);
		return OK_DIO;
		case(PORT_C):
		PORTC^=(1<<PINNUMBER);
		return OK_DIO;
		case(PORT_D):
		PORTD^=(1<<PINNUMBER);
		return OK_DIO;
		default:
		return wrongport;
	}
}
EN_dioError_t  DIO_read(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t * value)
{
	if(PINNUMBER>7 || PINNUMBER<0 )
	{
		return wrongPin;
	}
	switch(PORTNUMBER)
	{
	case(PORT_A):
	*value=(PINA &(1<<PINNUMBER))>>PINNUMBER;
	return OK_DIO;
	case(PORT_B):
	*value=(PINB &(1<<PINNUMBER))>>PINNUMBER;
	return OK_DIO;
	case(PORT_C):
	*value=(PINC &(1<<PINNUMBER))>>PINNUMBER;
	return OK_DIO;
	case(PORT_D):
	*value=(PIND &(1<<PINNUMBER))>>PINNUMBER;
	return OK_DIO;
	default:
	return wrongport;
	
	}
}