/*
 * timer.h
 *
 * Created: 9/30/2022 6:30:28 PM
 *  Author: Vivi
 */ 
#ifndef TIMER_H_
#define TIMER_H_
//#include "HARDWARE/Registers.h"
#include "../../HARDWARE/type.h"
typedef enum EN_timerError_t
{
	OK_timer, WrongTimer 
}EN_timerError_t;
#define TCCR2  *((volatile uint8_t *) 0x45)
#define TCNT2  *((volatile uint8_t *) 0x44)
#define TCCR0  *((volatile uint8_t *) 0x53)
#define TCNT0  *((volatile uint8_t *) 0x52)
#define TIMSK  *((volatile uint8_t *) 0x59)
#define TIFR   *((volatile uint8_t *) 0x58)
#define NoOfOverflows 23

void delayfiveseconds();//delay five seconds using timer0
void clearoverflow();//clear overflow flag
EN_timerError_t stoptimer(int x);//stop timer

#endif