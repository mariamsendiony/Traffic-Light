/*
 * timer.c
 *
 * Created: 9/30/2022 7:03:19 PM
 *  Author: Vivi
 */ 

#include "timer.h"
static unsigned int overflowcounter=0;


void delayfiveseconds()
{
//delay 1 second //T Tick=1024/10^6=1.024x19^-3 //T max delay=2^8*Ttick=262.144ms //no of overflows=1/262.144ms=4//initial =2^8-((1/Ttick)/4)=12
//Overflow max= 2^8 *T Tick
//no. of overflows =5/Overflow max =20
//initial value =12
//user timer 0 for delay five seconds and timer 2 for ISR
	//Normal mode
	
	
		TCCR0=0x00;
	//Timer initial value
	TCNT0=0x012;
	//prescaler 1024
	TCCR0=(1<<2)|(1<<0);
	while(overflowcounter<20)
	{
		while((TIFR && (1<<0))==0);
		clearoverflow();
		overflowcounter++;
	}
	stoptimer(0);
	overflowcounter=0;
	
	
}
void clearoverflow()
{
	TIFR |=(1<<0);
}
EN_timerError_t stoptimer(int x)
{
	switch(x)
	{
		case 0:
			TCCR0=0x00;
			return OK_timer;
		case 2:
			TCCR2=0x00;
		    return OK_timer;
		default:
		return WrongTimer;
	}
	
}
