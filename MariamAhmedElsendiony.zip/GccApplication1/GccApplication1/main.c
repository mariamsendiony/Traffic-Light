/*
 * GccApplication1.cpp
 *
 * Created: 9/28/2022 12:02:18 PM
 * Author : Vivi
 */ 

#include "Application/Application.h"
int main(void)
{
	Appstart();
     //Replace with your application code 
    while (1) 
    {
		 NormalMode();
    }
}

/*#include "Test Driver/Test.h"

int main(void)
{
  volatile	 EN_timerError_t n= Test_Timer(1);
  volatile	 EN_dioError_t m= Test_DIO(PORT_D,0,IN);
  volatile	 EN_ledError_t k= Test_LED(PORT_C,8);
	char G='G';
	volatile EN_buttonError_t p=Test_BUTTON(G,7);
	
}*/
