/*
 * Test.c
 *
 * Created: 10/10/2022 12:25:01 AM
 *  Author: Vivi
 */ 
#include "Test.h"
EN_dioError_t Test_DIO(uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t INOUT)
{
	EN_dioError_t  y=DIO_init( PORTNUMBER,PINNUMBER, INOUT );
	return y;
	if(y==wrongPin)
	{
		printf("wrong pin number\n");
	}
	else if(y==wrongport)
	{
		printf("wrong port\n");
	}
	else if(y==errordirection)
	{
		printf("wrong direction\n");
	}
	else
	{
		int value;
		EN_dioError_t  z=DIO_write(PORTNUMBER,PINNUMBER,value );
		if(z==errorvalue)
		{
			printf("wrong value not 1 or 0\n");
		}
		else
		{
			printf("OK DIO\n");
		}
	}
	
}
EN_ledError_t Test_LED(uint8_t ledport,uint8_t ledpin)
{
	EN_ledError_t  y=LED_init( ledport,ledpin );
	return y;
	if(y==LED_pin)
	{
		printf("wrong pin number\n");
	}
	else if(y==LED_port)
	{
		printf("wrong port\n");
	}
	else 
	{
		printf("OK LED\n");
	}
}
EN_buttonError_t Test_BUTTON(uint8_t BUTTONPORT,uint8_t BUTTONPIN )
{
	EN_buttonError_t  y=LED_init( BUTTONPORT, BUTTONPIN );
	return y;
	if(y==button_pin)
	{
		printf("wrong pin number\n");
	}
	else if(y==button_port)
	{
		printf("wrong port\n");
	}
	else
	{
		printf("OK Button \n");
	}
	
}
EN_timerError_t Test_Timer(int x)
{
	EN_timerError_t o= stoptimer( x);
	return o;
	if(o==WrongTimer)
	{
		printf("not timer 0 or 2\n");
	}
	else
	{
		printf("OK timer \n");
		
	}
	
	
}