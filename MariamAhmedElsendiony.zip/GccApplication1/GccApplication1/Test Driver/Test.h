/*
 * Test.h
 *
 * Created: 10/10/2022 12:27:03 AM
 *  Author: Vivi
 */ 
#ifndef TEST_H_
#define TEST_H_
#include <stdio.h>
#include "../MCUAL/TIMER DRIVER/timer.h"
#include "../MCUAL/DIO DRIVER/DIO.h"
#include "../HARDWARE/Registers.h"
#include "../HARDWARE/type.h"
#include "../ECUAL/BUTTON DRIVER/BUTTON.h"
#include "../ECUAL/LED DRIVER/LED.h"
#include "../ECUAL/EXTERNAL INTERRUPT/interrupt.h"

EN_dioError_t Test_DIO (uint8_t PORTNUMBER,uint8_t PINNUMBER,uint8_t INOUT);
EN_ledError_t Test_LED(uint8_t ledport,uint8_t ledpin);
EN_buttonError_t Test_BUTTON(uint8_t BUTTONPORT,uint8_t BUTTONPIN );
EN_timerError_t Test_Timer(int x);
#endif