#include "LED.h"
//typedef unsigned char uint8_t;
EN_ledError_t LED_init(uint8_t ledport,uint8_t ledpin )
{
	EN_dioError_t x=DIO_init(ledport,ledpin,OUT);//Since output device the direction is out by default
	if(x==wrongport)
	{
		return LED_port;
	}
	else if(x==wrongPin)
	{
		return LED_pin;
	}
	else
	{
		return OK_LED;
	}
	
}
EN_ledError_t LED_ON(uint8_t LEDPORT,uint8_t LEDPIN)
{
	EN_dioError_t x=DIO_write(LEDPORT,LEDPIN,HIGH);
	if(x==wrongport)
	{
		return LED_port;
	}
	else if(x==wrongPin)
	{
		return LED_pin;
	}
	else
	{
		return OK_LED;
	}
}
EN_ledError_t LED_OFF(uint8_t LEDPORT,uint8_t LEDPIN)
{
	
	EN_dioError_t x=DIO_write(LEDPORT,LEDPIN,LOW);
	if(x==wrongport)
	{
		return LED_port;
	}
	else if(x==wrongPin)
	{
		return LED_pin;
	}
	else
	{
		return OK_LED;
	}
}
EN_ledError_t LED_toggle(uint8_t LEDPORT,uint8_t LEDPIN)
{
	EN_dioError_t x=DIO_toggle(LEDPORT,LEDPIN);
	if(x==wrongport)
	{
		return LED_port;
	}
	else if(x==wrongPin)
	{
		return LED_pin;
	}
	else
	{
		return OK_LED;
	}
}
//void LED_blink(uint8_t ledport1,uint8_t ledpin1,uint8_t ledport2,uint8_t ledpin2)
/*{
	//Normal mode
	//TCCR2=0x00;
	//Timer initial value
	//TCNT2=0x12;
	//prescaler 1024
	//TCCR2 |=(1<<2)|(1<<1)|(1<<0);
	LED_toggle(ledport1,ledpin1);
	LED_toggle(ledport2,ledpin2);
	//TCCR2|=(1<<0);
	if((TIFR && (1<<0))==0) //overflow timer?
	{
		clearoverflow();
	}
	stoptimer(2);
	
}*/