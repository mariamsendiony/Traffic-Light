/*
 * LED.h
 *
 * Created: 9/28/2022 3:19:54 PM
 *  Author: Vivi
 */ 
#ifndef LED_H_
#define LED_H_
#include "../../MCUAL/DIO DRIVER/DIO.h"
//typedef unsigned char uint8_t;
#include "../../MCUAL/TIMER DRIVER/timer.h"
typedef enum EN_ledError_t
{
	OK_LED, LED_port,LED_pin
}EN_ledError_t;
EN_ledError_t LED_init(uint8_t ledport,uint8_t ledpin ); //initialize
EN_ledError_t LED_ON(uint8_t ledport,uint8_t ledpin); //LED ON
EN_ledError_t LED_OFF(uint8_t ledport,uint8_t ledpin); //LED OFF
EN_ledError_t LED_toggle(uint8_t ledport,uint8_t ledpin); //TOGGLE
//void LED_blink(uint8_t ledport1,uint8_t ledpin1,uint8_t ledport2,uint8_t ledpin2); //BLINK


#endif