/*
 * interrupt.h
 *
 * Created: 9/30/2022 6:34:29 PM
 *  Author: Vivi
 */ 
#ifndef INTERRUPT_H_
#define INTERRUPT_H_
//enable global interrupts
#define sei() __asm__ __volatile__ ("sei" ::: "memory");
//clear interrupts
#define cli() __asm__ __volatile__ ("cli" ::: "memory");
///////////////////////////////////////
#define T0_OVERFLOW  __vector_11
#define Timer2OVERFLOW  __vector_5
#define INT0  __vector_1
/////////////////////////////////////

#define INT_0_PIN 6
//bits to control what triggers the interrupt
#define  ISC00 0
#define  ISC01 1
#  define ISR(vector, ...)            \
void vector (void) __attribute__ ((signal,used)) __VA_ARGS__; \
void vector (void)


#endif