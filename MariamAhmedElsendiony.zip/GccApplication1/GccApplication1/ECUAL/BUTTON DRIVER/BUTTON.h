/*
 * BUTTON.h
 *
 * Created: 9/28/2022 4:05:05 PM
 *  Author: Vivi
 */ 
#ifndef BUTTON_H_
#define BUTTON_H_
#include "../../MCUAL/DIO DRIVER/DIO.h"
typedef enum EN_buttonError_t
{
	OK_button, button_port,button_pin
}EN_buttonError_t;
EN_buttonError_t BUTTON_init(uint8_t BUTTONPORT,uint8_t BUTTONPIN ); //initialize
EN_buttonError_t BUTTON_read(uint8_t BUTTONPORT,uint8_t BUTTONPIN,uint8_t * value);//read the button value 
#endif