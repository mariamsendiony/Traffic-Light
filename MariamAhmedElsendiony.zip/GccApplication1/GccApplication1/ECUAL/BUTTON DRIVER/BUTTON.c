/*
 * BUTTON.c
 *
 * Created: 9/28/2022 4:05:21 PM
 *  Author: Vivi
 */ 
#include "BUTTON.h"
EN_buttonError_t BUTTON_init(uint8_t BUTTONPORT,uint8_t BUTTONPIN )
{
	EN_dioError_t x=DIO_init(BUTTONPORT,BUTTONPIN,IN);//Button an input device
	if(x==wrongport)
	{
		return button_port;
	}
	else if(x==wrongPin)
	{
		return button_pin;
	}
	else
	{
		return OK_button;
	}
}
EN_buttonError_t BUTTON_read(uint8_t BUTTONPORT,uint8_t BUTTONPIN,uint8_t * value)
{
	EN_dioError_t x=DIO_read(BUTTONPORT,BUTTONPIN,value);
	if(x==wrongport)
	{
		return button_port;
	}
	else if(x==wrongPin)
	{
		return button_pin;
	}
	else
	{
		return OK_button;
	}
}