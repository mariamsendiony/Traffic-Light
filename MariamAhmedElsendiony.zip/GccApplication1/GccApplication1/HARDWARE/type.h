
/*
 * type.h
 *
 * Created: 9/28/2022 1:47:44 PM
 *  Author: Vivi
 */ 
#ifndef TYPE_H_
#define TYPE_H_
typedef unsigned char uint8_t;
#endif