/*
 * Application.c
 *
 * Created: 9/30/2022 8:23:53 PM
 *  Author: Vivi
 */ 
#include "Application.h"


unsigned int interruptflag=0;
uint8_t notpressed = 0;
int overflow2 = 0;
void Appstart()
{
	//CAR LED INTITIALIZATION
	LED_init(PORT_D,7);
	LED_init(PORT_A,0);//green
	LED_init(PORT_A,1);//yellow
	LED_init(PORT_A,2);//red
	//PEDESTRIAN LED INITIALIZATION
	LED_init(PORT_B,0);//green
	LED_init(PORT_B,1);//yellow
	LED_init(PORT_B,2);//red
	//BUTTON INITIALIZATION
	BUTTON_init(PORT_D,2);	
	sei();
	MCUCR |=(1<<ISC00);
	GICR |=(1<<INT_0_PIN);
	TIMSK |= (1<<6);
	
}
void delayfivesecondswithblink(uint8_t port1,uint8_t pin1,uint8_t port2,uint8_t pin2)
{
	
	TCCR0=0x00;
	//Timer initial value
	TCNT0=0x012;
	//prescaler 1024
	TCCR0 |= ((1<<2)|(1<<0));
	uint8_t overflowcounter = 0;
	while(overflowcounter<20)
	{
		if((TIFR && (1<<0))==1)
		{
			//LED_blink(port1,pin1,port2,pin2);
			if (overflowcounter %3 == 0){
				LED_toggle(port1,pin1);
				LED_toggle(port2,pin2);
			}

			overflowcounter++;
			clearoverflow();
			
		}
	}
	stoptimer(0);
	overflowcounter=0;
	
}
void NormalMode()
{   
  
	LED_ON(PORT_A,0);
	LED_ON(PORT_B,2);
	delayfiveseconds();
	LED_OFF(PORT_A,0);
	LED_OFF(PORT_B,2);
	LED_ON(PORT_A,1);
	LED_ON(PORT_B,1);
	delayfivesecondswithblink(PORT_A,1,PORT_B,1);
	LED_OFF(PORT_A,1);
	LED_OFF(PORT_B,1);
	LED_ON(PORT_A,2);
	LED_ON(PORT_B,0);
	delayfiveseconds();
	LED_OFF(PORT_A,2);
	LED_OFF(PORT_B,0);
	LED_ON(PORT_A,1);
	LED_ON(PORT_B,1);
	delayfivesecondswithblink(PORT_A,1,PORT_B,1);
	LED_OFF(PORT_A,1);
	LED_OFF(PORT_B,1);	
}

ISR(INT0)
{//int overflow;
	
	
	if(interruptflag==0)
	{   
		GIFR |= (1<<6);
		//overflow=0;
		overflow2=0;
		LED_ON(PORT_D,7);
		TCCR2=0x00;
		//Timer initial value
		TCNT2=0x12;
		//prescaler 1024
		TCCR2 |= ((1<<2)| (1<<1) |(1<<0));

		interruptflag = 1;
	
		
	}
	else 
	{
	
		if(overflow2 < 2)
		{
			LED_OFF(PORT_D,7);
			//As a pedestrian when I made a double press on the crosswalk button, I expect that the first press will do the action and nothing to be done after the second press,so clear all global interrupts till I finish the first press.
			cli();
			pedestrianmode();
			//after exiting pedestrian mode,enable interrupts and reset the interrupt flag.
			sei();
			interruptflag=0;
			NormalMode();			
		}	
		interruptflag=0;	
	}
}

void pedestrianmode()
{
	//check car leds
	TCCR0=0x00;
	//Timer initial value
	TCNT0=0x12;
	//prescaler 1024
	TCCR0 |= ((1<<2)|(1<<0));
	uint8_t  value0;
	uint8_t  value1;
	uint8_t  value2;
	DIO_read(PORT_A,0,&value0);
	DIO_read(PORT_A,1,&value1);
	DIO_read(PORT_A,2,&value2);
	if(value0 == 1 || (value2 != 1 && value0 != 1))
	{
		//car green or yellow led on
		//pedestrian led on
		LED_OFF(PORT_A,0);
		LED_ON(PORT_B,2); //Pedestrain red
		//both yellow leds on
		LED_ON(PORT_A,1);
		LED_ON(PORT_B,1);
		delayfivesecondswithblink(PORT_A,1,PORT_B,1);
		delayfivesecondswithblink(PORT_A,1,PORT_B,1);
		LED_OFF(PORT_A,1);
		LED_OFF(PORT_B,1);
		//car red on,green pedestrian on and turn off red led pedestrian
		LED_OFF(PORT_B,2);
		LED_ON(PORT_A,2);
		LED_ON(PORT_B,0);
		delayfiveseconds();
		delayfiveseconds();
		//The end of the state
		LED_OFF(PORT_A,2);
		//both yellow leds on and pedestrian green still on
		LED_ON(PORT_A,1);
		LED_ON(PORT_B,1);
		delayfivesecondswithblink(PORT_A,1,PORT_B,1);
		delayfivesecondswithblink(PORT_A,1,PORT_B,1);
		LED_OFF(PORT_A,1);
		LED_OFF(PORT_B,1);
		//close green pedestrian led
		LED_OFF(PORT_B,0);
		LED_OFF(PORTA,2);
		LED_ON(PORT_A,0);
		LED_ON(PORT_B,2);
	}

	if(value2==1)
	{
		//car red led on case
		LED_ON(PORT_A,2);
		LED_ON(PORT_B,0);
		delayfiveseconds();
		delayfiveseconds();
		//the red car led will be off
		LED_OFF(PORT_A,2);
		//both yellow leds on and pedestrian green still on
		LED_ON(PORT_A,1);
		LED_ON(PORT_B,1);
		delayfivesecondswithblink(PORT_A,1,PORT_B,1);
		delayfivesecondswithblink(PORT_A,1,PORT_B,1);
		LED_OFF(PORT_A,1);
		LED_OFF(PORT_B,1);
		//close green pedestrian led
		LED_OFF(PORT_B,0);
				LED_ON(PORT_A,0);
				LED_ON(PORT_B,2);
	}
}

ISR(Timer2OVERFLOW)
{
	overflow2++;
}