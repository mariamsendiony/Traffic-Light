/*
 * Application.h
 *
 * Created: 9/30/2022 8:23:31 PM
 *  Author: Vivi
 */ 

#ifndef APPLICATION_H_
#define APPLICATION_H_
//#include "../TIMER DRIVER/timer.h" ///
#include "../MCUAL/TIMER DRIVER/timer.h"
#include "../MCUAL/DIO DRIVER/DIO.h"
#include "../HARDWARE/Registers.h"
#include "../HARDWARE/type.h"
#include "../ECUAL/BUTTON DRIVER/BUTTON.h"
#include "../ECUAL/LED DRIVER/LED.h"
#include "../ECUAL/EXTERNAL INTERRUPT/interrupt.h"
void Appstart();
void NormalMode();
void pedestrianmode();
#endif